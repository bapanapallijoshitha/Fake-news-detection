/* FactGuard v8 — app.js
   Handles: 3 input types (text/img/doc) in BOTH single and compare modes
   Binary REAL/FAKE result rendering */

let S_TYPE  = 'text';   // single mode current tab
let CA_TYPE = 'text';   // compare A current tab
let CB_TYPE = 'text';   // compare B current tab
let LAST_ID = null;     // last check_id for feedback/download

/* ─── BOOT ───────────────────────────────────────────────── */
window.addEventListener('DOMContentLoaded', () => {
  loadStats();
  initDropzones();
  initCounters();
});

/* ─── STATS BAR ──────────────────────────────────────────── */
function loadStats() {
  fetch('/api/stats').then(r => r.json()).then(d => {
    setText('hTot',  d.total || 0);
    const fk = (d.by_verdict || []).filter(v => v.verdict === 'FAKE').reduce((a, v) => a + v.n, 0);
    const rl = (d.by_verdict || []).filter(v => v.verdict === 'REAL').reduce((a, v) => a + v.n, 0);
    setText('hFake', fk); setText('hReal', rl);
  }).catch(() => {});
}

/* ─── MODE SWITCH ────────────────────────────────────────── */
function setMode(m) {
  ge('modeSingle').classList.toggle('hidden', m !== 'single');
  ge('modeCompare').classList.toggle('hidden', m !== 'compare');
  ge('mSingle').classList.toggle('active', m === 'single');
  ge('mCompare').classList.toggle('active', m === 'compare');
}

/* ─── STEP 2 UNLOCK ──────────────────────────────────────── */
function unlockStep2() {
  if (!ge('sName').value.trim()) { fieldErr('sName','sEName'); return; }
  const p = ge('sStep2'); p.classList.remove('locked');
  p.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ─── SINGLE MODE INPUT TABS ─────────────────────────────── */
function setSingleType(t) {
  S_TYPE = t;
  ['text','img','doc'].forEach(x => {
    ge('sTab-' + x).classList.toggle('active', x === t);
    ge('sPane-' + x).classList.toggle('hidden', x !== t);
  });
}

/* ─── COMPARE MODE INPUT TABS ────────────────────────────── */
function setCmpType(side, t) {
  if (side === 'a') CA_TYPE = t; else CB_TYPE = t;
  const S = side.toUpperCase();
  ['text','img','doc'].forEach(x => {
    const tab  = ge('c' + S + 'Tab-' + x);
    const pane = ge('c' + S + 'Pane-' + x);  // note: Pane not Pan
    if (tab)  tab.classList.toggle('active', x === t);
    if (pane) pane.classList.toggle('hidden', x !== t);
  });
}

/* ─── CHAR COUNTERS ──────────────────────────────────────── */
function initCounters() {
  bindCounter('sText',  'sCC',  'sLang');
  bindCounter('cTextA', 'cCCA', null);
  bindCounter('cTextB', 'cCCB', null);
}
function bindCounter(textId, ccId, langId) {
  const el = ge(textId); if (!el) return;
  el.addEventListener('input', () => {
    const n = el.value.length;
    setText(ccId, n + ' char' + (n === 1 ? '' : 's'));
    if (langId) {
      const t = el.value, tot = Math.max(t.length, 1);
      const hi = (t.match(/[\u0900-\u097F]/g)||[]).length;
      const ta = (t.match(/[\u0B80-\u0BFF]/g)||[]).length;
      const te = (t.match(/[\u0C00-\u0C7F]/g)||[]).length;
      const lang = n > 5 ? (hi/tot>.1?'🇮🇳 Hindi':ta/tot>.1?'🇮🇳 Tamil':te/tot>.1?'🇮🇳 Telugu':'English') : '';
      setText(langId, lang ? 'Language: ' + lang : '');
    }
  });
}

/* ─── DROPZONES ──────────────────────────────────────────── */
function initDropzones() {
  const zones = [
    // Single mode
    'dzSImg:fSImg:sDzImgIdle:sDzImgPrev:sDzImgPic:sDzImgName',
    'dzSDoc:fSDoc:sDzDocIdle:sDzDocPrev:sDzDocPic:sDzDocName',
    // Compare A
    'cADzImg:cAFImg:cADzImgI:cADzImgP:cADzImgPic:cADzImgN',
    'cADzDoc:cAFDoc:cADzDocI:cADzDocP:cADzDocPic:cADzDocN',
    // Compare B
    'cBDzImg:cBFImg:cBDzImgI:cBDzImgP:cBDzImgPic:cBDzImgN',
    'cBDzDoc:cBFDoc:cBDzDocI:cBDzDocP:cBDzDocPic:cBDzDocN',
  ];
  zones.forEach(spec => {
    const [zId, inpId, idleId, prevId, picId, nameId] = spec.split(':');
    const dz = ge(zId); if (!dz) return;
    dz.addEventListener('dragover',  e => { e.preventDefault(); dz.style.borderColor = 'var(--gold)'; });
    dz.addEventListener('dragleave', () => { dz.style.borderColor = ''; });
    dz.addEventListener('drop', e => {
      e.preventDefault(); dz.style.borderColor = '';
      const f = e.dataTransfer.files[0]; if (!f) return;
      const dt = new DataTransfer(); dt.items.add(f);
      const inp = ge(inpId); if (!inp) return;
      inp.files = dt.files;
      onFileChosen(inp, idleId, prevId, picId, nameId);
    });
  });
}

function onFileChosen(inp, idleId, prevId, picId, nameId) {
  const f = inp.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = e => {
    const pic = ge(picId); if (pic) pic.src = e.target.result;
    setText(nameId, f.name);
    ge(idleId).classList.add('hidden');
    ge(prevId).classList.remove('hidden');
  };
  r.readAsDataURL(f);
}
function removeFile(e, inpId, idleId, prevId) {
  if (e) e.stopPropagation();
  const inp = ge(inpId); if (inp) inp.value = '';
  ge(idleId).classList.remove('hidden');
  ge(prevId).classList.add('hidden');
}

/* ─── ERROR HELPERS ──────────────────────────────────────── */
function fieldErr(inpId, errId) {
  const i = ge(inpId);
  if (i) { i.style.borderColor='var(--red)'; i.focus(); setTimeout(()=>i.style.borderColor='',3000); }
  showErr(errId);
}
function showErr(id) {
  const e = ge(id);
  if (e) { e.classList.add('show'); setTimeout(()=>e.classList.remove('show'),3000); }
}
function setLoad(lblId, spinId, btnId, on) {
  const l=ge(lblId),s=ge(spinId),b=ge(btnId);
  if(l) l.classList.toggle('hidden', on);
  if(s) s.classList.toggle('hidden', !on);
  if(b) b.disabled = on;
}

/* ─── SINGLE SUBMIT ──────────────────────────────────────── */
function doCheck(e) {
  e.preventDefault();
  const fd = new FormData();
  fd.append('name',  ge('sName').value.trim());
  fd.append('email', ge('sEmail').value.trim());

  if (S_TYPE === 'text') {
    const t = ge('sText').value.trim();
    if (!t) { showErr('sEText'); return; }
    fd.append('text', t);
  } else if (S_TYPE === 'img') {
    const f = ge('fSImg').files[0];
    if (!f) { showErr('sEImg'); return; }
    fd.append('file', f);
  } else {
    const f = ge('fSDoc').files[0];
    if (!f) { showErr('sEDoc'); return; }
    fd.append('file', f);
  }

  setLoad('sBtnText','sBtnSpin','sBtn', true);
  const out = ge('sResult');
  out.classList.remove('hidden');
  out.innerHTML = spinner('Analysing…');

  fetch('/api/check', { method:'POST', body:fd })
    .then(r => r.json())
    .then(d => {
      if (d.error) { out.innerHTML = errBox(d.error); return; }
      LAST_ID = d.check_id;
      out.innerHTML = buildResult(d);
      bindResultTabs(out);
      out.scrollIntoView({ behavior:'smooth', block:'start' });
      loadStats();
    })
    .catch(err => out.innerHTML = errBox(err.message))
    .finally(() => setLoad('sBtnText','sBtnSpin','sBtn', false));
}

/* ─── COMPARE SUBMIT ─────────────────────────────────────── */
function doCompare(e) {
  e.preventDefault();
  const name = ge('cName').value.trim();
  if (!name) { fieldErr('cName','cEName'); return; }

  const fd = new FormData();
  fd.append('name', name);
  fd.append('email', ge('cEmail').value.trim());

  // Side A
  if (CA_TYPE === 'text') {
    const t = ge('cTextA').value.trim(); if (!t) { showErr('cEA'); return; }
    fd.append('text_a', t);
  } else if (CA_TYPE === 'img') {
    const f = ge('cAFImg').files[0]; if (!f) { showErr('cEA'); return; }
    fd.append('file_a', f);
  } else {
    const f = ge('cAFDoc').files[0]; if (!f) { showErr('cEA'); return; }
    fd.append('file_a', f);
  }

  // Side B
  if (CB_TYPE === 'text') {
    const t = ge('cTextB').value.trim(); if (!t) { showErr('cEB'); return; }
    fd.append('text_b', t);
  } else if (CB_TYPE === 'img') {
    const f = ge('cBFImg').files[0]; if (!f) { showErr('cEB'); return; }
    fd.append('file_b', f);
  } else {
    const f = ge('cBFDoc').files[0]; if (!f) { showErr('cEB'); return; }
    fd.append('file_b', f);
  }

  setLoad('cBtnText','cBtnSpin','cBtn', true);
  const out = ge('cResult');
  out.classList.remove('hidden');
  out.innerHTML = spinner('Comparing both circulars…');

  fetch('/api/compare', { method:'POST', body:fd })
    .then(r => r.json())
    .then(d => {
      if (d.error) { out.innerHTML = errBox(d.error); return; }
      out.innerHTML = buildCompare(d);
      out.scrollIntoView({ behavior:'smooth', block:'start' });
      loadStats();
    })
    .catch(err => out.innerHTML = errBox(err.message))
    .finally(() => setLoad('cBtnText','cBtnSpin','cBtn', false));
}

/* ─── BUILD SINGLE RESULT ────────────────────────────────── */
function buildResult(d) {
  const isReal = d.verdict === 'REAL';
  const cls    = isReal ? 't-real' : 't-fake';
  const scoreStr = (d.raw_score > 0 ? '+' : '') + d.raw_score;
  const scoreColor = isReal ? 'var(--grn)' : 'var(--red)';
  const realSigs = d.positive_signals || [];
  const fakeSigs = d.fake_signals     || [];
  const missing  = d.missing_markers  || [];
  const facts    = d.real_facts       || [];
  const uid = 'u' + Date.now();

  // Evidence blocks
  let ev = '';
  if (realSigs.length) {
    ev += `<div class="ev"><div class="ev-h eh-r">✓ ${realSigs.length} Authentic signal${realSigs.length>1?'s':''} found</div>
      <div class="tags">${realSigs.map(s=>`<span class="tag tag-r">${x(s)}</span>`).join('')}</div></div>`;
  }
  if (fakeSigs.length) {
    ev += `<div class="ev"><div class="ev-h eh-f">⚠ ${fakeSigs.length} Suspicious signal${fakeSigs.length>1?'s':''} detected</div>
      <div class="tags">${fakeSigs.map(s=>`<span class="tag tag-f">${x(s)}</span>`).join('')}</div></div>`;
  }
  if (missing.length) {
    ev += `<div class="ev"><div class="ev-h eh-m">📋 Missing — markers a real document should have</div>
      <div class="tags">${missing.map(s=>`<span class="tag tag-m">${x(s)}</span>`).join('')}</div></div>`;
  }
  if (facts.length) {
    ev += `<div class="ev"><div class="ev-h eh-sci">📚 What science / facts actually say</div>
      ${facts.map(f=>`<div class="fact-item">✓ ${x(f)}</div>`).join('')}</div>`;
  }

  return `<div class="result-card ${cls}">
    <div class="rc-top">
      <div class="rc-verdict">
        <div class="rc-stamp">${d.verdict}</div>
        <div>
          <div class="rc-vword">${isReal?'✅ REAL':'⛔ FAKE'}</div>
          <div class="rc-msg">${x(d.message)}</div>
          <div class="rc-who">Checked by ${x(d.name||'Anonymous')}${d.email?' · '+x(d.email):''} · ${x(d.doc_type||'Content')}</div>
        </div>
      </div>
      <div class="rc-score">
        <div class="rc-score-n" style="color:${scoreColor}">${scoreStr}</div>
        <div class="rc-score-l">score</div>
        <div class="rc-conf">${d.confidence}% sure</div>
      </div>
    </div>

    ${ev}

    <div class="score-row">
      <div class="sbox" style="background:var(--ga2);border:1px solid var(--grb2)">
        <div class="sbox-n" style="color:var(--grn)">${realSigs.length}</div>
        <div class="sbox-l" style="color:var(--grn)">Real signals</div>
      </div>
      <div class="sbox" style="background:var(--ra);border:1px solid var(--rb2)">
        <div class="sbox-n" style="color:var(--red)">${fakeSigs.length}</div>
        <div class="sbox-l" style="color:var(--red)">Fake signals</div>
      </div>
      <div class="sbox" style="background:var(--oa);border:1px solid var(--ob2)">
        <div class="sbox-n" style="color:var(--org)">${missing.length}</div>
        <div class="sbox-l" style="color:var(--org)">Missing</div>
      </div>
      <div class="sbox" style="background:${isReal?'var(--ga2)':'var(--ra)'};border:1px solid ${isReal?'var(--grb2)':'var(--rb2)'}">
        <div class="sbox-n" style="color:${scoreColor}">${scoreStr}</div>
        <div class="sbox-l" style="color:${scoreColor}">Net score</div>
      </div>
    </div>

    <div class="rtabs">
      <button class="rtab on" data-target="${uid}-how">How scored</button>
      <button class="rtab" data-target="${uid}-prev">Content</button>
    </div>
    <div class="rtp on" id="${uid}-how">
      <p style="font-size:13px;color:var(--mu);line-height:1.7">
        Each authentic signal (F.No., date, Registrar, Copy to, etc.) gives <strong>negative points</strong>.
        Each fake signal (forward language, free giveaways, missing markers) gives <strong>positive points</strong>.
        <strong style="color:${scoreColor}">Score ${scoreStr} → ${d.verdict}.</strong>
        (Negative = REAL &nbsp;·&nbsp; Positive = FAKE)
      </p>
    </div>
    <div class="rtp" id="${uid}-prev">
      <div class="prev-box">${x(d.text_preview||'')}</div>
    </div>

    <div class="rc-footer">
      <div class="fb-row" id="${uid}-fb">
        <span class="fb-q">Was this verdict correct?</span>
        <button class="fb-y" onclick="sendFb('correct','${uid}-fb')">👍 Yes</button>
        <button class="fb-n" onclick="sendFb('incorrect','${uid}-fb')">👎 No</button>
      </div>
      <div class="rc-btns">
        <span class="src-pill">${d.source_type==='image'?'📷 Image OCR':'📄 Text'}</span>
        <button class="btn-ghost" onclick="resetSingle()">← Check another</button>
        <button class="btn-gold"  onclick="dlReport()">⬇ Report</button>
      </div>
    </div>
  </div>`;
}

/* ─── BUILD COMPARE RESULT ───────────────────────────────── */
function buildCompare(d) {
  const ra = d.result_a, rb = d.result_b;
  const aFake = d.more_fake === 'A', bFake = d.more_fake === 'B';
  let banCls = 'ban-tie', banHtml = '⚖️ Both sides show similar signals — no clear winner.';
  if (aFake) {
    banCls = 'ban-a';
    banHtml = `⛔ Circular A is <strong>FAKE</strong> &nbsp;·&nbsp; ✅ Circular B is <strong>REAL</strong><br><span style="font-size:13px;font-weight:400;opacity:.85">Score diff: ${d.score_diff} pts &nbsp;·&nbsp; B has stronger authenticity signals</span>`;
  } else if (bFake) {
    banCls = 'ban-b';
    banHtml = `✅ Circular A is <strong>REAL</strong> &nbsp;·&nbsp; ⛔ Circular B is <strong>FAKE</strong><br><span style="font-size:13px;font-weight:400;opacity:.85">Score diff: ${d.score_diff} pts &nbsp;·&nbsp; A has stronger authenticity signals</span>`;
  }

  const side = (r, ltr) => {
    const isReal = r.verdict === 'REAL';
    const sc = (r.raw_score>0?'+':'')+r.raw_score;
    const col = isReal ? 'var(--grn)' : 'var(--red)';
    const sigs = isReal ? (r.positive_signals||[]) : (r.fake_signals||[]);
    const missing = r.missing_markers || [];
    const facts = r.real_facts || [];
    return `<div class="crc ${isReal?'is-real':'is-fake'}">
      <div class="crc-label">Circular ${ltr}</div>
      <div class="crc-vword" style="color:${col}">${isReal?'✅ REAL':'⛔ FAKE'}</div>
      <div class="crc-score" style="color:${col}">Score ${sc} · ${(r.positive_signals||[]).length} real · ${(r.fake_signals||[]).length} fake</div>
      <div class="crc-conf">Confidence ${r.confidence}%</div>
      <div class="crc-tags">${sigs.slice(0,5).map(s=>`<span class="tag ${isReal?'tag-r':'tag-f'}">${x(s)}</span>`).join('')}</div>
      ${missing.length?`<div class="crc-tags">${missing.slice(0,3).map(s=>`<span class="tag tag-m">${x(s)}</span>`).join('')}</div>`:''}
      ${facts.length?`<div>${facts.slice(0,2).map(f=>`<div class="fact-mini">✓ ${x(f)}</div>`).join('')}</div>`:''}
      <div class="crc-preview">${x(r.text_preview||'')}</div>
    </div>`;
  };

  return `<div class="cmp-banner ${banCls}">${banHtml}</div>
  <div class="cmp-results">
    ${side(ra,'A')}
    <div class="crc-sep"><div class="crc-sep-line"></div><div class="crc-sep-vs">VS</div><div class="crc-sep-line"></div></div>
    ${side(rb,'B')}
  </div>
  <div style="text-align:center;padding:6px 0 14px">
    <button class="btn-ghost" onclick="resetCompare()">← Compare again</button>
  </div>`;
}

/* ─── RESULT TABS ────────────────────────────────────────── */
function bindResultTabs(container) {
  container.querySelectorAll('.rtab').forEach(btn => {
    btn.addEventListener('click', () => {
      const card = btn.closest('.result-card'); if (!card) return;
      card.querySelectorAll('.rtab').forEach(b => b.classList.remove('on'));
      card.querySelectorAll('.rtp').forEach(p => p.classList.remove('on'));
      btn.classList.add('on');
      const p = document.getElementById(btn.getAttribute('data-target'));
      if (p) p.classList.add('on');
    });
  });
}

/* ─── FEEDBACK / DOWNLOAD ────────────────────────────────── */
function sendFb(rating, fbRowId) {
  if (!LAST_ID) return;
  fetch('/api/feedback', { method:'POST', headers:{'Content-Type':'application/json'},
    body:JSON.stringify({check_id:LAST_ID, rating}) })
    .then(() => {
      const el = document.getElementById(fbRowId);
      if (el) el.innerHTML = '<span style="font-size:13px;color:var(--grn);font-weight:600">✓ Thank you for the feedback!</span>';
    });
}
function dlReport() { if (LAST_ID) window.location.href = '/api/report/' + LAST_ID; }

/* ─── RESET ──────────────────────────────────────────────── */
function resetSingle() {
  ge('sResult').classList.add('hidden');
  ge('sText').value = '';
  setText('sCC','0 chars'); setText('sLang','');
  setSingleType('text');
  LAST_ID = null;
  window.scrollTo({ top:0, behavior:'smooth' });
}
function resetCompare() {
  ge('cResult').classList.add('hidden');
  ge('cTextA').value=''; ge('cTextB').value='';
  setText('cCCA','0 chars'); setText('cCCB','0 chars');
  window.scrollTo({ top:0, behavior:'smooth' });
}

/* ─── LOADING / ERROR HTML ───────────────────────────────── */
function spinner(msg) {
  return `<div class="card" style="text-align:center;padding:48px">
    <div style="display:inline-block;width:38px;height:38px;border:3px solid var(--b2);border-top-color:var(--gold);border-radius:50%;animation:spin .8s linear infinite"></div>
    <div style="font-family:'Lora',serif;font-size:15px;font-style:italic;color:var(--mu);margin-top:14px">${msg}</div>
  </div>`;
}
function errBox(msg) {
  return `<div class="card" style="color:var(--red);border-color:var(--rb2);background:var(--ra)">⚠ ${x(msg)}</div>`;
}

/* ─── UTILS ──────────────────────────────────────────────── */
const ge  = id => document.getElementById(id);
const setText = (id, v) => { const e=ge(id); if(e) e.textContent=v; };
const x = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

/* ─── SIMPLE FILE INPUT HELPERS ──────────────────────────── */
function onSimpleFileChosen(input, wrapId, chosenId, placeholderId) {
  const file = input.files[0];
  if (!file) return;
  const chosen = ge(chosenId);
  const placeholder = ge(placeholderId);
  if (!chosen || !placeholder) return;
  chosen.querySelector('.sfn-name').textContent = file.name;
  chosen.classList.remove('hidden');
  placeholder.classList.add('hidden');
}

function removeSimpleFile(event, inputId, wrapId, chosenId, placeholderId) {
  event.preventDefault();
  event.stopPropagation();
  const input = ge(inputId);
  if (input) { input.value = ''; }
  const chosen = ge(chosenId);
  const placeholder = ge(placeholderId);
  if (chosen) chosen.classList.add('hidden');
  if (placeholder) placeholder.classList.remove('hidden');
}
